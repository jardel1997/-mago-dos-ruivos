# SEO INTELLIGENCE PRO
Sistema de referência operacional para SEO + GEO + AEO + AIO.

Inspirado no repositório público Illyism/seo-skills (https://github.com/Illyism/seo-skills).
Este pacote é uma estrutura adaptada para uso em projetos web e negócios locais; não é uma cópia dos arquivos originais do repositório.

## Objetivo
Auditar, planejar, implementar e monitorar otimizações para pesquisa orgânica tradicional e mecanismos de busca/answer engines baseados em IA, sem prometer rankings ou citações garantidas.

## Como usar
1. Leia `SYSTEM_PROMPT.md` para instruções de execução.
2. Use `workflows/` para procedimentos passo a passo.
3. Preencha templates em `templates/` e registre evidências em `reports/`.
4. Priorize tarefas por impacto, confiança, esforço e risco.
5. Valide as alterações antes de recomendar publicação.

## Módulos
- Technical SEO audit
- Keyword & SERP research
- Local SEO
- GEO / AI search visibility
- Content strategy & coverage gaps
- Competitor intelligence
- Authority & link strategy
- SEO growth & monitoring
- Title/meta optimization
- Schema structured data
- Core Web Vitals & accessibility basics

## Limitações e ética
- Não invente métricas, volumes de busca, rankings, citações de IA, backlinks, tráfego ou resultados.
- Não garanta posicionamento, tráfego, leads ou inclusão em respostas de IA.
- Distinga fatos verificados, hipóteses e recomendações.
- Use fontes confiáveis e cite URLs/data de consulta nos relatórios.
- Evite conteúdo spam, doorway pages, keyword stuffing, backlinks manipulativos e avaliações falsas.
- Dados privados ou credenciais nunca devem ser incluídos nos relatórios.
