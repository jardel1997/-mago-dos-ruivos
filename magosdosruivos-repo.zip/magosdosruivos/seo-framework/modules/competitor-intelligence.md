# Competitor Intelligence

- Defina concorrentes diretos, indiretos e SERP competitors.
- Analise páginas posicionadas, proposta de valor, conteúdo, arquitetura, UX, sinais de confiança e ofertas.
- Registre URLs e evidências datadas.
- Identifique gaps: tópicos, páginas, perguntas, recursos e diferenciação.
- Não copie conteúdo, marca, layout ou ativos protegidos.
- Não inferir tráfego, backlinks ou conversões sem dados; marcar estimativas.
