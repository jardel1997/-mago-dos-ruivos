# Keyword & SERP Research

## Processo
1. Identifique serviço/produto, público, região e objetivo.
2. Gere temas iniciais e variações; valide em fontes atuais quando possível.
3. Classifique intenção: informacional, comercial, transacional, navegacional, local.
4. Observe SERP: resultados orgânicos, mapas, snippets, perguntas, páginas e formatos.
5. Agrupe termos por tópico e intenção, evitando canibalização.
6. Escolha termos primários e secundários por relevância, não só volume.
7. Defina página-alvo e ação/conversão para cada grupo.

## Registro
- Termo / cluster
- Intenção
- Região/idioma
- Evidência de SERP e URL consultada
- Volume (somente se medido em fonte; senão N/D)
- Competitividade (estimativa claramente marcada)
- Página sugerida
- Prioridade e justificativa
