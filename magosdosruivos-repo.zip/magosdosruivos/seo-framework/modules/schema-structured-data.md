# Structured Data / Schema

- Escolher tipos Schema.org adequados ao conteúdo real (ex.: Organization, LocalBusiness, Person, Service, Article, FAQPage quando elegível).
- Schema deve refletir conteúdo visível e verificável.
- Validar sintaxe e propriedades com ferramentas oficiais.
- Não inventar avaliações, preços, localização, autor, disponibilidade ou atributos.
- Schema não garante rich results, ranking ou citações em IA.
