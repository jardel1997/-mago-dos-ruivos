# Local SEO

## Checklist
- [ ] Perfil da Empresa no Google existe e está acessível (se verificado)
- [ ] Nome, endereço e telefone consistentes (NAP)
- [ ] Categorias e serviços apropriados
- [ ] Horário, área de atendimento e contato atualizados
- [ ] Site contém endereço/área atendida e dados coerentes
- [ ] Páginas locais têm conteúdo útil e original, não páginas duplicadas por cidade
- [ ] Fotos reais e atuais, quando disponíveis
- [ ] Processo ético de solicitação de avaliações (sem compra/fabricação)
- [ ] Respostas a avaliações e dúvidas
- [ ] Links e citações locais relevantes

Nunca invente endereço, área atendida, avaliações, categorias ou informações do Perfil da Empresa.
