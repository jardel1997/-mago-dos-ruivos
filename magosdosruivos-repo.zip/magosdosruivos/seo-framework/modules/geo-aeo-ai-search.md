# GEO / AEO / AI Search Visibility

## Objetivo
Ajudar mecanismos generativos e sistemas de resposta a compreenderem o negócio e suas informações, e aumentar potencial de descoberta/citação sem garantir que isso aconteça.

## Boas práticas
- Informações comerciais claras e consistentes
- Definições diretas de serviços, especialidades e público
- Conteúdo original, útil, atualizado e verificável
- Autor, credenciais e experiência quando verdadeiros e pertinentes
- FAQ com perguntas reais e respostas concisas
- Heading e estrutura semântica clara
- Entidades e relações bem definidas
- Schema apenas para fatos presentes e visíveis
- Referências e fontes de confiança quando apropriado
- Páginas de serviço completas, diferenciadas e úteis
- Evitar claims vazios, conteúdo repetitivo e páginas produzidas só para manipular IA

## Reportar
- O que a IA/buscador foi efetivamente testado?
- Em qual ferramenta, prompt, data, idioma e localização?
- Resultado observado (registrar resposta e URL/fonte quando houver)
- Limitações e variações
- Oportunidades de melhoria
