# Technical SEO Audit

## Checklist
- [ ] URLs acessíveis e status HTTP corretos
- [ ] HTTPS e canonical apropriados
- [ ] Robots.txt não bloqueia páginas essenciais
- [ ] Sitemap XML válido e atualizado
- [ ] Indexabilidade e diretivas meta robots
- [ ] Redirecionamentos e erros 404/5xx
- [ ] Canonicals consistentes; evitar duplicação
- [ ] Mobile responsiveness e usability
- [ ] Core Web Vitals (LCP, INP, CLS), quando medidos
- [ ] Imagens otimizadas, dimensões, formatos, alt text contextual
- [ ] HTML semântico e headings hierárquicos
- [ ] Links internos e páginas órfãs
- [ ] Schema válido e coerente com conteúdo visível
- [ ] Segurança básica e HTTPS
- [ ] Acessibilidade básica (labels, contraste, teclado, alt)

## Evidência
Para cada item, registrar URL, observação, fonte/método, data, impacto e validação.
