# Title, Meta Description & On-page Optimization

## Revisão por página
- Um título único, descritivo e alinhado à intenção
- Termo principal natural, sem repetição forçada
- Meta description útil e honesta; não é garantia de snippet
- H1 claro e compatível com o conteúdo
- Headings organizam a leitura
- CTA alinhado à intenção
- Links internos relevantes
- Alt text descreve imagem informativa; imagens decorativas podem ter alt vazio
- Evitar títulos clickbait, promessas falsas e stuffing
