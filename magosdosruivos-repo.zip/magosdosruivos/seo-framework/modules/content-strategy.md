# Content Strategy & Coverage

## Processo
1. Definir público e etapas da jornada.
2. Organizar tópicos centrais e clusters.
3. Identificar dúvidas reais (SERP, FAQ, clientes, fontes).
4. Mapear lacunas e conteúdo concorrente sem copiar.
5. Definir formato, propósito e CTA de cada página.
6. Elaborar brief: intenção, termo principal, termos relacionados, estrutura, fontes, autoria/experiência e atualização.
7. Revisar originalidade, utilidade, precisão e leitura.

## Conteúdo a evitar
- Páginas quase idênticas com troca superficial de cidade/keyword
- Conteúdo genérico sem experiência ou valor original
- Keyword stuffing e textos feitos apenas para volume
- FAQs inventadas como se fossem dúvidas reais
