# SEO Growth & Monitoring

## KPIs, quando acessíveis
- Impressões, cliques, CTR e posição média (Search Console)
- Sessões orgânicas, engajamento e conversões (GA4)
- Indexação e cobertura
- Core Web Vitals
- Leads/conversões por landing page
- Visibilidade local e métricas do perfil (quando acessíveis)
- Experimentos e mudanças implementadas

## Ciclo
Baseline → hipótese → mudança → validação → aprendizado → próximo ciclo.

Registrar período, origem, segmento, alterações e limitações. Não atribuir causalidade sem evidência suficiente.
