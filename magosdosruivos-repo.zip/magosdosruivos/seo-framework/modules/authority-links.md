# Authority & Link Strategy

## Diretrizes
- Priorizar fontes legítimas e relações editoriais reais.
- Buscar parcerias, associações, imprensa local, recursos úteis e citações pertinentes.
- Reforçar links internos para páginas importantes com âncoras naturais.
- Auditar backlinks apenas quando houver ferramenta/dados disponíveis.
- Evitar compra de links manipulativos, redes de links, troca excessiva, spam ou âncoras artificiais.
