# Web Performance & UX

- Medir, não supor: Lighthouse/PageSpeed ou dados de campo quando disponíveis.
- Verificar LCP, INP, CLS; registrar fonte e contexto.
- Otimizar imagens (tamanho, compressão, dimensões, lazy loading adequado).
- Reduzir JS/CSS não usados, scripts pesados e fontes excessivas.
- Evitar layout shift e garantir resposta rápida.
- Testar mobile, teclado, contraste e formulários.
- Priorizar melhorias por impacto na experiência, não apenas score.
