# SEO Implementation Checklist

## Before changes
- [ ] Baseline saved
- [ ] URL/page scope confirmed
- [ ] Backups/version control

## Technical
- [ ] Crawl/index directives checked
- [ ] Canonical and redirects reviewed
- [ ] Sitemap and robots reviewed
- [ ] Schema validated
- [ ] Performance tested

## Content
- [ ] Intent mapped
- [ ] Title/meta/H1 optimized
- [ ] Content useful and original
- [ ] Internal links
- [ ] Images and alt text

## Local/GEO (if applicable)
- [ ] Business facts consistent
- [ ] Local page helpful, non-duplicative
- [ ] AI search test documented (if performed)

## Post-change
- [ ] Changes documented
- [ ] Validation performed
- [ ] Monitoring plan
