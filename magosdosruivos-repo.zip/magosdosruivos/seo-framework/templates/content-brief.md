# Content Brief

**Tema:**  
**Página / URL alvo:**  
**Público:**  
**Região:**  
**Intenção:**  
**Keyword principal:**  
**Keywords relacionadas (validadas):**  
**Perguntas reais / fontes:**  
**Diferencial / experiência original:**  
**Título sugerido:**  
**H1:**  
**Outline H2/H3:**  
**Links internos:**  
**Fontes externas:**  
**CTA:**  
**Schema (se aplicável):**  
**Revisão factual:**  
**Critérios de qualidade:** utilidade, originalidade, clareza, precisão, legibilidade.
