# SEO Audit Report

**Projeto / negócio:**  
**URL:**  
**Data:**  
**Região / idioma:**  
**Objetivo principal:**  
**Acesso e ferramentas:**  

## Resumo executivo

## Limitações / dados não acessíveis

## Achados prioritários
### P0
- Problema:
- Evidência:
- Impacto:
- Correção:
- Validação:

### P1
### P2

## Keywords & intenção

## SEO técnico

## On-page & conteúdo

## SEO local

## GEO/AEO

## Plano de ação
| Prioridade | Tarefa | Impacto | Esforço | Confiança | Validação |
|---|---|---|---|---|

## Próxima medição
