# Reports
Armazene relatórios concluídos aqui. Cada relatório deve incluir URL, data, fontes, evidências, limitações e plano de ação. Não guardar credenciais ou dados sensíveis.
