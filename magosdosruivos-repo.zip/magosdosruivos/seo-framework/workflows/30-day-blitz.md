# Workflow: 30-Day SEO Blitz

## Semana 1 — Diagnóstico & baseline
- Validar acesso, indexação, technical audit, objetivo e métricas disponíveis.

## Semana 2 — Fundamentos
- Corrigir problemas P0/P1, títulos, estrutura, páginas de serviço e links internos.

## Semana 3 — Conteúdo & local
- Criar/atualizar conteúdo prioritário, FAQ real, perfil local e schema apropriado.

## Semana 4 — GEO, validação & monitoramento
- Revisar entidades, clareza, citações/fontes, performance; medir mudanças e preparar ciclo seguinte.

O plano é adaptável. Não simular métricas nem prometer resultados em 30 dias.
