# Workflow: GEO / AI Search Report

1. Identificar negócio, entidade, serviços, região e público.
2. Auditar clareza, consistência, conteúdo original, fontes, estrutura e schema.
3. Se testar plataformas de IA, registrar plataforma, data, prompt, região e resultados observados.
4. Separar teste real de hipótese.
5. Identificar lacunas de conteúdo e entidades.
6. Recomendar melhorias.
7. Não garantir citações, menções ou recomendações de IA.
