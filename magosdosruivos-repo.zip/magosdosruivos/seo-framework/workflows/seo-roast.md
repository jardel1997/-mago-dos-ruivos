# Workflow: SEO Roast

1. Confirmar URL, negócio, público, localidade e objetivo.
2. Acessar página; se acesso indisponível, pedir HTML, screenshots ou arquivos.
3. Registrar evidências e limitações.
4. Avaliar técnico, on-page, conteúdo, local, UX e GEO/AEO.
5. Classificar achados P0/P1/P2.
6. Entregar crítica direta, sem exagerar nem afirmar métricas não medidas.
7. Criar lista de correções e critérios de validação.

## Formato
- Nota de escopo (não score inventado)
- 5 problemas mais importantes
- Evidências
- Correções específicas
- Quick wins
- Próximo ciclo
