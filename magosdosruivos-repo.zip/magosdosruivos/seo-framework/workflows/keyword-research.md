# Workflow: Keyword Research

1. Definir negócio, serviço, público, região e conversão.
2. Criar sementes e variações.
3. Pesquisar SERPs e ferramentas disponíveis.
4. Classificar intenção.
5. Agrupar em clusters e mapear páginas.
6. Marcar volume/competição como N/D quando não houver dados.
7. Recomendar plano editorial e arquitetura.
