# Workflow: Competitor Analysis

1. Confirmar região e concorrentes.
2. Pesquisar concorrentes reais e SERP competitors.
3. Coletar URLs e evidências.
4. Comparar proposta, páginas, conteúdo, serviços, confiança, UX e SEO.
5. Mapear oportunidades de diferenciação.
6. Produzir ações sem copiar conteúdo.
