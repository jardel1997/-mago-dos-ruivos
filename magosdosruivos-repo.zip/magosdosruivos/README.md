# Mago dos Ruivos — Nilson Gonçalves

Site de SEO local para o especialista em cabelos ruivos Nilson Gonçalves.

- **Endereço:** Rua Estados Unidos, 273 — Jardins, São Paulo/SP, CEP 01427-000
- **Domínio:** https://magosdosruivosoficial.com.br (Registro.br, hospedagem Cloudflare)
- **Site:** pasta `site/` (HTML estático, sem build)

## Estrutura

```
site/            -> arquivos publicados (index.html, robots.txt, sitemap.xml, og-image.jpg)
docs/            -> plano de SEO, pendências e checklist
seo-framework/   -> pacote SEO Intelligence Pro (método de trabalho, não roda no site)
```

## Publicar na Cloudflare Pages (conectado ao GitHub)

1. Cloudflare > Workers & Pages > Create > Pages > **Connect to Git** e escolha este repositório.
2. Build command: **vazio**. Build output directory: **`site`**.
3. Depois do primeiro deploy: Custom domains > adicionar `magosdosruivosoficial.com.br`.
4. Criar redirecionamento de `www` para o domínio sem `www`.

Cada commit na branch principal publica uma nova versão.

## Regras do projeto

- Não alterar o design sem aprovação.
- Não inventar endereço, telefone, horário, avaliações ou área de atendimento.
- Não criar páginas repetidas trocando só o nome da cidade.
- Sem promessa de posição no Google nem de citação por IA.
