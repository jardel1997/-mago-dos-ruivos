# Plano de SEO local, GEO e AEO — Mago dos Ruivos

Data do diagnóstico: 23/11/2026. Legenda: VERIFICADO, ESTIMATIVA, HIPÓTESE, NÃO DISPONÍVEL.

## Já aplicado no site (site/index.html)
- Título com especialidade e local primeiro.
- Subtítulo do topo com "nos Jardins, São Paulo" (H1 poético mantido).
- Open Graph, Twitter Card, imagem de compartilhamento (1200x630) e canonical.
- Schema HairSalon enriquecido: url, image, sameAs (Instagram, TikTok, Maps), areaServed, founder (Nilson), serviços.
- Serviços em HTML estático (antes só por JavaScript).
- Links reais de WhatsApp, Instagram e TikTok no HTML.
- robots.txt e sitemap.xml.

## Pendências que dependem do Nilson (não inventar)
1. Grafia oficial: "Mago dos Ruivos" ou "Magos dos Ruivos" (o domínio usa "magos").
2. O WhatsApp (DDD 19) é o canal oficial? Existe telefone de São Paulo (DDD 11)?
3. Horários de atendimento e formas de pagamento reais.
4. Atende clientes de outras cidades? Quais?
5. Acesso ao Perfil da Empresa no Google e ao Instagram.
6. Fotos de antes/depois com autorização; experiência e formação publicáveis.
7. Publicar faixa de valores ou explicar o processo de avaliação?

## Próximos passos
| Prioridade | Tarefa | Depende de |
|---|---|---|
| P0 | Publicar o site no domínio e verificar no Search Console | Cloudflare + conta Google |
| P0 | Confirmar nome, telefone, horário e bairro (Maps) | Nilson |
| P0 | Otimizar Perfil da Empresa no Google | Acesso ao perfil |
| P1 | Telefone e horário no site e no schema (após confirmar) | Nilson |
| P1 | Rastrear cliques em WhatsApp e "Como chegar" | GA4 |
| P1 | Página "Ruivo sem descolorir" com casos reais | Fotos autorizadas |
| P1 | Biografia factual do Nilson | Nilson |
| P2 | Páginas "Tons de ruivo" e "Ruivo em cabelo cacheado" | Fotos |
| P2 | "Como chegar" e "Vindo de outra cidade" (sem páginas por bairro) | Dados reais |
| P2 | Rotina ética de avaliações; citações locais | Nilson |
| P2 | Teste mensal em buscadores e IAs, registrado | Acesso |

## Geografia (HIPÓTESE, validar no Maps)
- Entorno: Jardim América, Jardim Paulista, Cerqueira César, Itaim Bibi, Pinheiros, Consolação, Bela Vista/Paulista.
- Grande SP: Osasco, Barueri, Guarulhos, Santo André, São Bernardo, entre outras.
- Viagem planejada: Campinas, Jundiaí, Sorocaba.
Só criar página local de uma cidade se houver conteúdo próprio e verdadeiro. Caso contrário, uma página "Vindo de outra cidade".

## Concorrentes observados (23/11/2026)
Rodrigo Castellari (thehairdresser.com.br), Gleici Duarte / Rainha dos Ruivos, Cor e Cacho SP, Laboratório da Beleza, Richard Ruiz Studio Color, Ruivos Campinas. O gancho "ruivo sem descolorir" é compartilhado: precisa de prova (casos reais, processo, limites).

## Medição
Linha de base antes de mudar: Search Console, GA4, Perfil do Google, PageSpeed mobile. Ciclo de 30 dias: baseline, hipótese, mudança, validação, aprendizado.
