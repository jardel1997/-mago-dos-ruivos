# Checklist de implantação

## Antes de mudar
- [ ] Linha de base salva (Search Console, GA4, PageSpeed)
- [ ] Escopo confirmado
- [ ] Versão anterior no histórico do Git

## Técnico
- [ ] Site abre no domínio com HTTPS
- [ ] www redireciona para o domínio sem www
- [ ] robots.txt e sitemap.xml acessíveis
- [ ] Sitemap enviado no Search Console
- [ ] Schema validado (Rich Results Test / validator.schema.org)
- [ ] Prévia de compartilhamento testada no WhatsApp
- [ ] PageSpeed mobile medido

## Conteúdo
- [ ] Dados de contato iguais em site, Google, Instagram e TikTok
- [ ] Alt text revisado
- [ ] FAQ com dúvidas reais dos clientes

## Depois
- [ ] Mudanças documentadas
- [ ] Plano de monitoramento ativo
