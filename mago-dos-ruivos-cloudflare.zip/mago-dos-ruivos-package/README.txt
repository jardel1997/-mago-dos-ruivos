MAGOS DOS RUIVOS — PROJETO WEBSITE

Arquivo principal:
- index.html

Este é um site estático de página única. As imagens do projeto estão embutidas no HTML.
O site usa recursos externos via CDN para GSAP, ScrollTrigger, Three.js e fontes Google.
Portanto, para a experiência completa, é necessária conexão à internet.

Para publicar no Cloudflare Pages:
1. Descompacte este arquivo ZIP.
2. Envie a pasta do projeto ou o index.html para o Cloudflare Pages (upload direto de assets estáticos).
3. Se for usar o método de upload de arquivos, mantenha index.html na raiz.
