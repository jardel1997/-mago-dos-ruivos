# Mago dos Ruivos — Nilson Gonçalves

Site do Mago dos Ruivos, em HTML estático. Arquivo único: `index.html`.

Publicação (Cloudflare Pages): build command e output directory em branco (raiz).
